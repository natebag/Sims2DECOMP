ProDG Profiling for Nintendo GameCube SDK Sep 8 2001     4-Feb-2002
-------------------------------------------------------------------

Copyright (c) SN Systems Ltd 2002, All rights reserved
 
This patch must be applied to SDK Sep 8 2001
This pacth is not required for later releases.

INSTALLATION
------------

1:

You will need to run a snarl script to modify the Nintendo SDK
libraries to allow the profiling to function.

Run 'snarl -E' from a command prompt to force snarl to register
its script file extension.

2:
Locate 'patchNGClibs.sns' in the 'Profiling' folder of your Pro-DG
installation and 'double-click' to execute the script.

The script will make OSDefaultExceptionHandler global, and weaken
PPCHalt and PPCMtdec.

The new version of PPCHalt in libsn.a has a user breakpoint in it
to allow postmortem debugging.



DolphinSDK1.0.zip INSTALLATION
------------------------------


DolphinSDK1.0.zip contains the files 'OSFastCast.h, "types.h" and 'GDLight.h'.
These replace the files with the same name in your DolphinSDK1.0
directory.
The files in the DolphinSDK1.0.zip archive already contain the correct path.
For a default installation of the Nintendo SDK extract to C:\
Other wise extract to the directory containing your DolphinSDK1.0 directory.


SUPPORT
-------
If you have any questions or feedback please send it to ngcsupport@snsys.com  

It would be very helpful if anyone submitting a problem report
can run versions.bat (in .\NGC) and send us the resulting report.txt
along with a description of their problem.

------------------------------------------------------------------------



