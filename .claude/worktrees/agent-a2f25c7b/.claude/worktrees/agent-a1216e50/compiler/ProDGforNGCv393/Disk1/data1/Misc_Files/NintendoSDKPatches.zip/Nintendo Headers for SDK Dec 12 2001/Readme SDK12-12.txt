ProDG for Nintendo GameCube                                   4-Feb-2002
------------------------------------------------------------------------

Copyright (c) SN Systems Ltd 2002, All rights reserved

This archive contains the changes needed to Pro-DG release 3.8 for the latest
Nintendo SDK; '12th-Dec-2001'. 


INSTALLATION
------------
DolphinSDK1.0.zip contains the files 'OSFastCast.h',Types.h and 'GDLight.h'.
These replace the files with the same name in your DolphinSDK1.0
directory.
The files in the DolphinSDK1.0.zip archive already contain the correct path.
For a default installation of the Nintendo SDK extract to C:\
Other wise extract to the directory containing your DolphinSDK1.0 directory.

BUILDING PROGRAMS
-----------------

To use the Nintendo supplied makefile system, please add the definition

SNSYS=1

to your environment variables.

This may have already been set up by the ProDG installer.  

SUPPORT
-------
If you have any questions or feedback please send it to ngcsupport@snsys.com  

It would be very helpful if anyone submitting a problem report
can run versions.bat (in .\NGC) and send us the resulting report.txt
along with a description of their problem.

------------------------------------------------------------------------